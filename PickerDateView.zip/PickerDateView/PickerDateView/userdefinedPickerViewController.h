//
//  leatherMyOrderViewController.h
//  restaurant_reservation
//
//  Created by jetson-luokehua on 15/5/6.
//  Copyright (c) 2015年 罗小华. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface userdefinedPickerViewController : UIViewController<UIPickerViewDataSource, UIPickerViewDelegate>


@property (weak, nonatomic) IBOutlet UIPickerView *pickerView;
typedef enum : NSUInteger {
    QuitWithResult, //When confirm button is pressed
    QuitWithBackButton, //When back button is pressed
    QuitWithCancel, //when View outside date picker is pressed
} HSDatePickerQuitMethod;

typedef enum : NSUInteger {
    StepOneMinute = 1,
    StepTwoMinutes = 2,
    StepFiveMinutes = 5,
    StepTenMinutes = 10,
    StepFifteenMinutes = 15,
    StepHalfAnHour = 30,
} HSDatePickerMinutesStep;


/**
 *  Indidcate that ViewController should be dismiss when there is touch outside date picker. Default is YES.
 */
@property (nonatomic, assign, getter=shouldDismissOnCancelTouch) BOOL dismissOnCancelTouch;
/**
 *  Minute picker step value. Default StepFiveMinutes
 */
@property (nonatomic, assign) HSDatePickerMinutesStep minuteStep;
/**
 *  am/pm
 */
@property (nonatomic, assign) HSDatePickerMinutesStep isam;
/**
 *  Color of interface elements
 */
@property (nonatomic, strong) UIColor *mainColor;
/**
 *  Selected date. Warning! Don't read selected date from this variable. User NSDatePickerViewControllerDelegate protocol instead.
 */
@property (nonatomic, strong) NSDate *date;
/**
 *  Maximum avaiable date on picker
 */
@property (nonatomic, strong) NSDate *minDate;
/**
 *  Maximum avaiable date on picker
 */
@property (nonatomic, strong) NSDate *maxDate;
/**
 *  Formater for date in picker. Default format is "ccc d MMM"
 */
@property (nonatomic, strong) NSDateFormatter *dateFormatter;
@property (nonatomic, strong) NSDateFormatter *amFormatter;

/**
 *  Format month and date label above date picker. Default format is "MMMM yyyy"
 */
@property (nonatomic, strong) NSDateFormatter *monthAndYearLabelDateFormater;
/**
 *  Title of picker confirm button
 */
@property (nonatomic, strong) NSString *confirmButtonTitle;
/**
 *  Back button title
 */
@property (nonatomic, strong) NSString *backButtonTitle;

@end
