//
//  leatherMyOrderViewController.m
//  restaurant_reservation
//
//  Created by jetson-luokehua on 15/5/6.
//  Copyright (c) 2015年 罗小华. All rights reserved.
//

#import "userdefinedPickerViewController.h"
typedef enum : NSUInteger {
    DayPicker = 0,
    HourPicker = 1,
    MinutePicker = 2,
    am = 3,
} HSDatePickerType;

static NSInteger kRowsMultiplier = 200;
static NSInteger kBufforRows = 30; //Number of rows that are prevent by scroll picker to end

@interface userdefinedPickerViewController ()
@property (nonatomic, assign) NSInteger maxRowIndex;
@property (nonatomic, assign) NSInteger minRowIndex;

@end

@implementation userdefinedPickerViewController
@synthesize minDate = _minDate;
@synthesize maxDate = _maxDate;
-(void)loadView
{

    [super loadView];
    self.minRowIndex = self.maxRowIndex = -1;
    self.minuteStep = StepOneMinute;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    [self.navigationItem setHidesBackButton:YES];
    [self.navigationController.navigationBar setHidden:YES];

    for (NSUInteger i = 0; i < 3; i++) {
        [self.pickerView selectRow:[self defaultRowValueForComponent:i] inComponent:i animated:NO];
    }
    
    [self pickerView:self.pickerView didSelectRow:[self defaultRowValueForComponent:DayPicker] inComponent:DayPicker];
    
    NSDateComponents *components = [[NSCalendar currentCalendar] components:(NSCalendarUnitHour | NSCalendarUnitMinute) fromDate:self.date];
    [self setPickerView:self.pickerView rowInComponent:HourPicker toIntagerValue:[components hour] decrementing:NO animated:NO];
    [self setPickerView:self.pickerView rowInComponent:MinutePicker toIntagerValue:[components minute]  decrementing:NO animated:NO];

    // Do any additional setup after loading the view from its nib.
}


#pragma mark - Properties
- (UIColor *)mainColor {
    if (!_mainColor) {
        _mainColor = [UIColor whiteColor];
    }
    return _mainColor;
}

- (NSDate *)date {
    if (!_date) {
        _date = [NSDate date];
    }
    return _date;
}

- (void)setMinDate:(NSDate *)minDate {
    if ([minDate compare:self.date] == NSOrderedDescending) {
        NSLog(@"minDate=%@ is after date=%@. Value will not be set.", minDate, self.date);
    } else {
        _minDate = minDate;
    }
}

- (NSDate *)minDate {
    if (!_minDate) {
        _minDate = [self dateForRow:kBufforRows];
    }
    return _minDate;
}

- (void)setMaxDate:(NSDate *)maxDate {
    if ([maxDate compare:self.date] == NSOrderedAscending) {
        NSLog(@"maxDate=%@ is before date=%@. Value will not be set.", maxDate, self.date);
    } else {
        _maxDate = maxDate;
    }
}

- (NSDate *)maxDate {
    if (!_maxDate) {
        _maxDate = [self dateForRow:[self pickerView:self.pickerView numberOfRowsInComponent:DayPicker] - kBufforRows];
    }
    return _maxDate;
}

- (NSDateFormatter *)dateFormatter {
    if (!_dateFormatter) {
        _dateFormatter = [NSDateFormatter new];
        _dateFormatter.dateFormat = @"LL  dd  EE";
        _dateFormatter.locale = [[NSLocale alloc] initWithLocaleIdentifier:@"zh_CN"];
    }
    return _dateFormatter;
}

- (NSDateFormatter *)monthAndYearLabelDateFormater {
    if (!_monthAndYearLabelDateFormater) {
        _monthAndYearLabelDateFormater = [NSDateFormatter new];
        _monthAndYearLabelDateFormater.dateFormat = @"MMMM yyyy";
    }
    return _monthAndYearLabelDateFormater;
}

- (NSString *)confirmButtonTitle {
    if (!_confirmButtonTitle) {
        _confirmButtonTitle = NSLocalizedString(@"Set date", @"HSDatePicker confirm button title");
    }
    return _confirmButtonTitle;
}

- (NSString *)backButtonTitle {
    if (!_backButtonTitle) {
        _backButtonTitle = NSLocalizedString(@"Back", @"HSDatePicker back button");
    }
    return _backButtonTitle;
}

- (NSInteger)maxRowIndex {
    if (_maxRowIndex == -1) {
        if ([self.maxDate compare:[self dateForRow:[self pickerView:self.pickerView numberOfRowsInComponent:DayPicker] - kBufforRows]] == NSOrderedAscending) {
            _maxRowIndex = [self defaultRowValueForComponent:DayPicker] + [self daysBetweenDate:self.date andDate:self.maxDate];
        }
        else {
            _maxRowIndex = [self pickerView:self.pickerView numberOfRowsInComponent:DayPicker] - kBufforRows;
        }
    }
    return _maxRowIndex;
}

- (NSInteger)minRowIndex {
    if (_minRowIndex == -1) {
        if ([self.minDate compare:[self dateForRow:kBufforRows]] == NSOrderedDescending) {
            _minRowIndex = [self defaultRowValueForComponent:DayPicker] + [self daysBetweenDate:self.date andDate:self.minDate];
        }
        else {
            _minRowIndex = kBufforRows;
        }
    }
    return _minRowIndex;
}

#pragma mark - UIPickerViewDataSource
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    return 4;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    //To implement wrap around effect for components we return big number.
    //Real number of components you can get from realNumberOfRowsInComponent
    return [self realNumberOfRowsInComponent:component] * kRowsMultiplier;
}

- (NSInteger)realNumberOfRowsInComponent:(NSInteger)component {
    NSInteger numberOfRows = 0;
    switch (component) {
        case DayPicker:
            numberOfRows = 30;
            break;
        case HourPicker:
            numberOfRows = 24;
            break;
        case MinutePicker:
            numberOfRows = 60 / self.minuteStep;
            break;
        case am:
            numberOfRows = 24;
            break;
    }
    
    return numberOfRows;
}

- (NSInteger)defaultRowValueForComponent:(NSInteger)component {
    return [self realNumberOfRowsInComponent:component] * kRowsMultiplier / 2;
}

#pragma mark - UIPickerViewDelegate

- (CGFloat)pickerView:(UIPickerView *)pickerView widthForComponent:(NSInteger)component {
    CGFloat width = 0.0;
    switch (component) {
        case DayPicker:
            width = 140;
            break;
        case HourPicker:
            width = 60;
            break;
        case MinutePicker:
            width = 60;
            break;
        case am:
            width = 60;
            break;
    }
    
    return width;
}


- (NSAttributedString *)pickerView:(UIPickerView *)pickerView attributedTitleForRow:(NSInteger)row forComponent:(NSInteger)component {
    NSString *title = @"";
    NSMutableParagraphStyle *paragraphStyle = [NSMutableParagraphStyle new];

    switch (component) {
        case DayPicker:
            title = [self stringDateForRow:row];
            [paragraphStyle setAlignment:NSTextAlignmentLeft];
            break;
        case HourPicker:
            title = [NSString stringWithFormat:@"%02ld", row % [self realNumberOfRowsInComponent:component]];
            [paragraphStyle setAlignment:NSTextAlignmentCenter];
            
            break;
        case MinutePicker:
            title = [NSString stringWithFormat:@"%02lu", row % [self realNumberOfRowsInComponent:component] * self.minuteStep];
            [paragraphStyle setAlignment:NSTextAlignmentCenter];
            
            break;
        case am:
            
            if (row % [self realNumberOfRowsInComponent:HourPicker] <12) {
                title = @"AM";
                [paragraphStyle setAlignment:NSTextAlignmentCenter];
            }else
            {
                title = @"PM";
                [paragraphStyle setAlignment:NSTextAlignmentCenter];
            }
            
            break;
    }
    
    
    return [[NSAttributedString alloc] initWithString:title attributes:
            @{NSForegroundColorAttributeName: self.mainColor,
              NSParagraphStyleAttributeName: paragraphStyle}];
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component {
    if (component == DayPicker) {
        
        //If picker values are to close to bufforValue scroll it back
        if (row < self.minRowIndex) {
            [self.pickerView selectRow:self.minRowIndex inComponent:component animated:YES];
            [self pickerView:self.pickerView didSelectRow:self.minRowIndex inComponent:component];
        }
        if (row > self.maxRowIndex) {
            [self.pickerView selectRow:self.maxRowIndex inComponent:component animated:YES];
            [self pickerView:self.pickerView didSelectRow:self.maxRowIndex inComponent:component];
        }
        //Disable month change buttons

    }
    
    if ( component == HourPicker) {
        [pickerView selectRow:row inComponent:am animated:YES];
    }
    NSInteger firstComponentRowValue = [pickerView selectedRowInComponent:DayPicker];
    //If picker values are to close to bufforValue scroll it back
    if (firstComponentRowValue <= self.minRowIndex) {
        NSDateComponents *components = [[NSCalendar currentCalendar] components:(NSCalendarUnitHour | NSCalendarUnitMinute) fromDate:self.minDate];
        [self setPickerView:self.pickerView rowInComponent:HourPicker toIntagerValue:[components hour] decrementing:NO animated:YES];
        [self setPickerView:self.pickerView rowInComponent:MinutePicker toIntagerValue:[components minute]  decrementing:NO animated:YES];
    }
    if (firstComponentRowValue >= self.maxRowIndex) {
        NSDateComponents *components = [[NSCalendar currentCalendar] components:(NSCalendarUnitHour | NSCalendarUnitMinute) fromDate:self.maxDate];
        [self setPickerView:self.pickerView rowInComponent:HourPicker toIntagerValue:[components hour] decrementing:YES animated:YES];
        [self setPickerView:self.pickerView rowInComponent:MinutePicker toIntagerValue:[components minute]  decrementing:YES animated:YES];
    }
}

- (void)setPickerView:(UIPickerView *)pickerView rowInComponent:(NSInteger)component toIntagerValue:(NSInteger)value decrementing:(BOOL)decrementing animated:(BOOL)animated {
    if (decrementing) {
        BOOL valueSetted = NO;
        for (NSInteger i = 0; i < [self realNumberOfRowsInComponent:component]; i++) {
            if ([[self pickerView:pickerView attributedTitleForRow:[pickerView selectedRowInComponent:component] - i forComponent:component].string integerValue] <= value) {
                [pickerView selectRow:[pickerView selectedRowInComponent:component] - i inComponent:component animated:animated];
                valueSetted = YES;
                break;
            }
        }
        
        if (!valueSetted && component == MinutePicker) {
            [pickerView selectRow:[pickerView selectedRowInComponent:HourPicker] - 1 inComponent:HourPicker animated:animated];
            if ([[self pickerView:pickerView attributedTitleForRow:[pickerView selectedRowInComponent:HourPicker] forComponent:HourPicker].string integerValue] == 0) {
                [pickerView selectRow:[pickerView selectedRowInComponent:DayPicker] - 1 inComponent:DayPicker animated:animated];
            }
        }
    } else {
        BOOL valueSetted = NO;
        for (NSInteger i = 0; i < [self realNumberOfRowsInComponent:component]; i++) {
            if ([[self pickerView:pickerView attributedTitleForRow:[pickerView selectedRowInComponent:component] + i forComponent:component].string integerValue] >= value) {
                [pickerView selectRow:[pickerView selectedRowInComponent:component] + i inComponent:component animated:animated];
                valueSetted = YES;
                break;
            }
        }
        if (!valueSetted && component == MinutePicker) {
            [pickerView selectRow:[pickerView selectedRowInComponent:HourPicker] + 1 inComponent:HourPicker animated:animated];
            if ([[self pickerView:pickerView attributedTitleForRow:[pickerView selectedRowInComponent:HourPicker] forComponent:HourPicker].string integerValue] == 0) {
                [pickerView selectRow:[pickerView selectedRowInComponent:DayPicker] + 1 inComponent:DayPicker animated:animated];
            }
        }
        if ( component == HourPicker) {
            [pickerView selectRow:[pickerView selectedRowInComponent:HourPicker]  inComponent:am animated:YES];
        }
    }
}

#pragma mark - NSDate operations
-(BOOL)isDate:(NSDate*)date1 sameDayAsDate:(NSDate*)date2 {
    NSCalendar* calendar = [NSCalendar currentCalendar];
    
    unsigned unitFlags = NSCalendarUnitYear | NSCalendarUnitMonth |  NSCalendarUnitDay;
    NSDateComponents* comp1 = [calendar components:unitFlags fromDate:date1];
    NSDateComponents* comp2 = [calendar components:unitFlags fromDate:date2];
    
    return [comp1 day]   == [comp2 day] &&
    [comp1 month] == [comp2 month] &&
    [comp1 year]  == [comp2 year];
}

- (NSInteger)daysInMonth:(NSDate *)date {
    return [[NSCalendar currentCalendar] rangeOfUnit:NSCalendarUnitDay
                                              inUnit:NSCalendarUnitMonth
                                             forDate:date].length;
}

- (NSDate *)dateForRow:(NSInteger)row {
    row = row - [self defaultRowValueForComponent:DayPicker];
    NSDate * date = [self.date dateByAddingTimeInterval:60 * 60 * 24 * row];
    return [[NSCalendar currentCalendar] dateBySettingHour:0 minute:0 second:0 ofDate:date options:0];
}

- (NSString *)stringDateForRow:(NSUInteger)row {
    NSDate *date = [self dateForRow:row];
    if ([self isDate:date sameDayAsDate:[NSDate date]]) {
        return NSLocalizedString(@"Today", @"Current day indicator");
    }
    return [self.dateFormatter stringFromDate:date];
}


//http://stackoverflow.com/questions/4739483/number-of-days-between-two-nsdates
- (NSInteger)daysBetweenDate:(NSDate*)fromDateTime andDate:(NSDate*)toDateTime
{
    NSDate *fromDate;
    NSDate *toDate;
    
    NSCalendar *calendar = [NSCalendar currentCalendar];
    
    [calendar rangeOfUnit:NSCalendarUnitDay startDate:&fromDate
                 interval:NULL forDate:fromDateTime];
    [calendar rangeOfUnit:NSCalendarUnitDay startDate:&toDate
                 interval:NULL forDate:toDateTime];
    
    NSDateComponents *difference = [calendar components:NSCalendarUnitDay
                                               fromDate:fromDate toDate:toDate options:0];
    
    return [difference day];
}

- (NSDate *)dateWithSelectedTime {
    NSDate *date = [self dateForRow:[self.pickerView selectedRowInComponent:DayPicker]];
    NSInteger hour = [[self pickerView:self.pickerView attributedTitleForRow:[self.pickerView selectedRowInComponent:HourPicker] forComponent:HourPicker].string integerValue];
    NSInteger minute = [[self pickerView:self.pickerView attributedTitleForRow:[self.pickerView selectedRowInComponent:MinutePicker] forComponent:MinutePicker].string integerValue];
    return [[NSCalendar currentCalendar] dateBySettingHour:hour minute:minute second:0 ofDate:date options:0];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/



@end
